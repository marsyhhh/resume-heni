<!doctype html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../css/app.css">
    <style type="text/tailwindcss">
        @layer base {
        html {
            font-family: "roboto";
            color: rgb(67, 74, 84);
        }
    }
  </style>
</head>

<body class="bg-color1">

    <?php if(session()->has('message')): ?>
    <div id="confirmation" class="fixed z-10 inset-0 overflow-y-auto">
        <div class="flex items-center justify-center h-screen pt-4 px-4 pb-20 text-center">
            <div class="fixed inset-0 transition-opacity">
                <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span class="sm:inline-block sm:align-middle sm:h-screen"></span>&#8203;

            <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <h3 class="text-xl leading-6 font-medium text-gray-900">
                        Message
                    </h3>
                    <div class="mt-2">
                        <p class="text-sm text-gray-500">
                            <?php echo e(session()->get('message')); ?>

                        </p>
                    </div>
                </div>
                <div class="bg-white px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button id="allow" type="button" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-red-600 text-base font-medium text-white hover:bg-red-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 sm:ml-3 sm:w-auto sm:text-sm">
                        Close
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <nav class="z-50 fixed w-full opacity-80 bg-white">
        <div class="flex items-center justify-between px-14 py-4 text-base font-light shadow-md">
            <div></div>
            <div class="flex items-center">
                <a href="#about" class="mr-4">About</a>
                <a href="#skill" class="mr-4">Skills</a>
                <a href="#education" class="mr-4">Education</a>
                <a href="#experience" class="mr-4">Experience</a>
                <a href="#portofolio" class="mr-4">Portofolio</a>
            </div>
            <?php if(Route::has('login')): ?>
            <div class="">
                <?php if(auth()->guard()->check()): ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <a href="route('logout')" onclick="event.preventDefault();
                                        this.closest('form').submit();">
                        <?php echo e(__('Log Out')); ?>

                    </a>
                </form>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </nav>

    <div id="about" class="mx-36 px-10 pt-16 shadow-xl absolute mt-14 bg-white z-0">
        <!-- about -->
        <div class="grid grid-cols-3 gap-4 items-center">
            <div class="shadow-xl p-2 mr-auto">
                <img class="object-center" src="img/pp.jpg" alt="" width="200">
            </div>
            <div class="col-span-2">
                <h1 class="font-bold text-5xl mb-1">Heni Rosdianti</h1>
                <p class="mb-6">Mahasiswa Aktif & E-Commerce Specialist</p>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-4 my-10">
            <div>
                <h2 class="font-bold text-2xl">About Me</h2>
                <p class="mt-10">Heni Rosdianti adalah Seorang yang
                    berpengalaman dalam bidang marketing
                    digital, khususnya di marketplace dan sosial
                    media. Dengan lebih dari 4 tahun
                    pengalaman dalam industri marketing
                    digital ia telah berhasil membantu
                    meningkatkan visibilitas dan penjualan
                    produk yang berkembang pesat dengan
                    rate penjualan tertinggi pada perusahaan secara online.</p>
            </div>
            <div class="grid grid-cols-3 items-center pl-10">
                <div>
                    <div>LinkedIn</div>
                    <div>Email</div>
                    <div>Phone</div>
                    <div>Address</div>
                </div>
                <div class="col-span-2">
                    <div>Heni Rosdianti</div>
                    <div>hrosdianti11@gmail.com</div>
                    <div>+62 857-0386-0267</div>
                    <div>Ciawi, Tasikmalaya 46156</div>
                </div>
            </div>
        </div>
        <hr>
        <!-- skill -->
        <div id="skill" class="my-10">
            <div class="flex justify-center">
                <h2 class="font-bold text-2xl">Soft, Hard, & Language Skill</h2>
            </div>
            <div class="grid grid-cols-2 gap-4 mt-4">
                <div class="mr-8">
                    <div class="mt-2">
                        <div>Komunikasi</div>
                        <div class="bg-color3/20 h-4 rounded-full">
                            <div class="bg-color3 h-full w-[90%] flex items-center justify-center text-white text-xs">90%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>Problem Solving</div>
                        <div class="bg-color3/20 h-4 rounded-full">
                            <div class="bg-color3 h-full w-[80%] flex items-center justify-center text-white text-xs">80%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>Manajemen Waktu</div>
                        <div class="bg-color3/20 h-4 rounded-full">
                            <div class="bg-color3 h-full w-[85%] flex items-center justify-center text-white text-xs">85%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>Negosiasi</div>
                        <div class="bg-color3/20 h-4 rounded-full">
                            <div class="bg-color3 h-full w-[87%] flex items-center justify-center text-white text-xs">87%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>Leadership</div>
                        <div class="bg-color3/20 h-4 rounded-full">
                            <div class="bg-color3 h-full w-[85%] flex items-center justify-center text-white text-xs">85%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>Kolaborasi Tim</div>
                        <div class="bg-color3/20 h-4 rounded-full">
                            <div class="bg-color3 h-full w-[85%] flex items-center justify-center text-white text-xs">85%</div>
                        </div>
                    </div>
                </div>
                <div class="ml-8">
                    <div class="mt-2">
                        <div>E-Commerce</div>
                        <div class="bg-color2/20 h-4 rounded-full">
                            <div class="bg-color2 h-full w-[88%] flex items-center justify-center text-white text-xs">88%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>Copy Writing</div>
                        <div class="bg-color2/20 h-4 rounded-full">
                            <div class="bg-color2 h-full w-[80%] flex items-center justify-center text-white text-xs">80%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>Sosial Media Marketing</div>
                        <div class="bg-color2/20 h-4 rounded-full">
                            <div class="bg-color2 h-full w-[80%] flex items-center justify-center text-white text-xs">80%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>Seo & Sem</div>
                        <div class="bg-color2/20 h-4 rounded-full">
                            <div class="bg-color2 h-full w-[80%] flex items-center justify-center text-white text-xs">80%</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>B. Indonesia</div>
                        <div class="bg-color2/20 h-4 rounded-full">
                            <div class="bg-color2 h-full w-[100%] flex items-center justify-center text-white text-xs">Native</div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <div>B. Inggris</div>
                        <div class="bg-color2/20 h-4 rounded-full">
                            <div class="bg-color2 h-full w-[100] flex items-center justify-center text-white text-xs">Intermediate</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <!-- education -->
        <div id="education" class="my-10">
            <div class="flex justify-center">
                <h2 class="font-bold text-2xl">Education</h2>
            </div>

            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            <a class="underline text-sky-600 hover:text-black" href="/viewAddEducation">+Add Education</a>
            <?php endif; ?>
            <?php endif; ?>

            <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border-l-4 border-cyan-600/20 ml-3 py-8">
                <div class="relative">
                    <div class="absolute top-5 -left-3.5 bg-color2 h-6 w-6 rounded-full border-4 border-white"></div>
                    <div class="pl-10 w-[500px]">
                        <div class="font-bold text-xl"><?php echo e($e->title); ?></div>
                        <div class="text-sm break-words"><?php echo e($e->description); ?>l</div>

                        <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                        <a class="underline text-sky-600 hover:text-black text-sm" href="<?php echo e(url('delEducation', $e->id)); ?>">-Delete</a>
                        <?php endif; ?>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr>
        <!-- experience -->
        <div id="experience" class="my-10">
            <div class="flex justify-center">
                <h2 class="font-bold text-2xl">Experience</h2>
            </div>

            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            <a class="underline text-sky-600 hover:text-black" href="/viewAddExperience">+Add Experience</a>
            <?php endif; ?>
            <?php endif; ?>

            <?php $__currentLoopData = $experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border-l-4 border-cyan-600/20 ml-3 py-8">
                <div class="relative">
                    <div class="absolute top-5 -left-3.5 bg-cyan-600 h-6 w-6 rounded-full border-4 border-white"></div>
                    <div class="pl-10 w-[500px]">
                        <div class="font-bold text-xl"><?php echo e($x->title); ?></div>
                        <div class="text-base"><?php echo e($x->subtitle); ?></div>
                        <div class="text-sm break-words"><?php echo e($x->description); ?></div>

                        <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                        <a class="underline text-sky-600 hover:text-black text-sm" href="<?php echo e(url('delExperience', $x->id)); ?>">-Delete</a>
                        <?php endif; ?>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr>
        <!-- portofolio -->
        <div id="portofolio" class="my-10">
            <div class="flex justify-center">
                <h2 class="font-bold text-2xl">Portofolio</h2>
            </div>
            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            <a class="underline text-sky-600 hover:text-black" href="/viewAddPortofolio">+Add Portofolio</a>
            <?php endif; ?>
            <?php endif; ?>

            <div class="flex flex-wrap justify-center">
                <?php $__currentLoopData = $portofolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="group h-96 w-96 [perspective:1000px] m-6">
                    <div class="relative h-full w-full rounded-xl shadow-xl transition-all duration-500 [transform-style:preserve-3d] group-hover:[transform:rotateY(180deg)]">
                        <div class="absolute inset-0">
                            <img class="h-full w-full rounded-xl object-cover shadow-lg" src="portofolio/<?php echo e($p->image); ?>">
                        </div>
                        <div class="absolute inset-0 h-full w-full rounded-xl bg-black/40 px-12 text-center text-slate-200 [transform:rotateY(180deg)] [backface-visibility:hidden]">
                            <div class="flex min-h-full flex-col items-center justify-center">
                                <div class="text-3xl font-semibold"><?php echo e($p->title); ?></div>
                                <div class="text-lg mb-2"><?php echo e($p->subtitle); ?></div>
                                <div class="text-sm"><?php echo e($p->description); ?></div>

                                <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>
                                <a class="underline text-sky-600 hover:text-black text-sm" href="<?php echo e(url('delPortofolio', $p->id)); ?>">-Delete</a>
                                <?php endif; ?>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <hr>
        <hr>
        <!-- discuss -->
        <section class="py-8 my-10 antialiased">
            <div class="max-w-2xl mx-auto px-4">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-lg font-bold">Discussion (<?php echo e($countDiscus); ?>)</h2>
                </div>
                <form class="mb-6" action="<?php echo e(url('/addDiscus')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="py-2 px-4 mb-4 rounded-lg rounded-t-lg border border-gray-200">
                        <label for="comment" class="sr-only">Your comment</label>
                        <input type="text" name="name" class="px-0 w-full text-sm border-0 focus:ring-0 focus:outline-none" placeholder="name" required>
                    </div>
                    <div class="py-2 px-4 mb-4 rounded-lg rounded-t-lg border border-gray-200">
                        <label for="comment" class="sr-only">Your comment</label>
                        <textarea name="comment" rows="6" class="px-0 w-full text-sm border-0 focus:ring-0 focus:outline-none" placeholder="Write a comment..." required></textarea>
                    </div>
                    <button type="submit" class="inline-flex items-center text-white py-2.5 px-4 text-xs font-medium text-center bg-color2 rounded-lg focus:ring-4 focus:ring-primary-200 hover:bg-color2/80">
                        Post comment
                    </button>
                </form>
                <?php $__currentLoopData = $discus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="p-6 text-base rounded-lg">
                    <footer class="flex justify-between items-center mb-2">
                        <div class="flex items-center">
                            <p class="inline-flex items-center mr-3 text-sm font-semibold"><?php echo e($d->name); ?></p>
                            <p class="text-sm "><time pubdate datetime="2022-02-08" title="February 8th, 2022"><?php echo e($d->created_at); ?></time></p>
                        </div>
                    </footer>
                    <p class=""><?php echo e($d->comment); ?></p>

                    <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                    <a class="underline text-sky-600 hover:text-black text-sm" href="<?php echo e(url('delDiscus', $d->id)); ?>">-Delete</a>
                    <?php endif; ?>
                    <?php endif; ?>
                </article>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>

    <script>
        const modal = document.getElementById("confirmation");

        document.addEventListener("click", (e) => {
            if (e.target.id === "openModal") {
                modal.classList.remove("hidden");
            } else if (e.target.id === "allow" || e.target.id === "deny") {
                modal.classList.add("hidden");
            }
        });
    </script>
</body>

</html><?php /**PATH C:\Users\faaja\Desktop\Project and Learn\resumeApp\resources\views/welcome.blade.php ENDPATH**/ ?>